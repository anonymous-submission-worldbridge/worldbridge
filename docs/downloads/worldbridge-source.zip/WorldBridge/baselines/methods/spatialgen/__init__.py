"""spatialgen baseline implementation."""
