"""gpt baseline implementation."""
