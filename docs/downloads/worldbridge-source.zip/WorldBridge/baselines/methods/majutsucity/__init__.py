"""majutsucity baseline implementation."""
