"""infinigen baseline implementation."""
