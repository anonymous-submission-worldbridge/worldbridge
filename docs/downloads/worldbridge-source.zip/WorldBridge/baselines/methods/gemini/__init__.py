"""gemini baseline implementation."""
