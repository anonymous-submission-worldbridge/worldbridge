"""syncity baseline implementation."""
