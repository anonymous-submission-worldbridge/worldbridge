"""glm baseline implementation."""
