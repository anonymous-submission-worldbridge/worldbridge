"""sceneweaver baseline implementation."""
