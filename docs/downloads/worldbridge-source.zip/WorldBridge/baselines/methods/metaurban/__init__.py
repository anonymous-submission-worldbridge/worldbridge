"""metaurban baseline implementation."""
