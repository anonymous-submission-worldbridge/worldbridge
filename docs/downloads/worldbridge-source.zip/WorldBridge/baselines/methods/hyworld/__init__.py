"""hyworld baseline implementation."""
