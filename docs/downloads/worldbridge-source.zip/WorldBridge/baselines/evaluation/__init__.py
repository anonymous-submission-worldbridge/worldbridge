"""Shared baseline evaluation components."""
